/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factura;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.conexion.Conexion;
import modelo.entidades.Cabecera;
import modelo.entidades.Cliente;
import modelo.entidades.DetalleFactura;
import modelo.entidades.Factura;
import modelo.entidades.Producto;
import modelo.logica.ManejadorCabecera;
import modelo.logica.ManejadorCliente;
import modelo.logica.ManejadorDetalleFactura;
import modelo.logica.ManejadorFacturacion;

/**
 *
 * @author gabriel
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        ManejadorCabecera manejador = new ManejadorCabecera();
//        ManejadorFacturacion facturacion = new ManejadorFacturacion();
//        ManejadorDetalleFactura detalle=new ManejadorDetalleFactura();
//        Cliente cliente = new Cliente("0605722404", "soto", "comite del pueblo", "0999999999");
//        Producto producto=new Producto(1, "bananas");
//
//        Cabecera cabecera = manejador.crearCabecera(1, cliente, "12-12-2017");
//        Factura factura =facturacion.CrearFactura(1, cabecera);
//        DetalleFactura detail=new DetalleFactura(1, 140, 45, 12, 1230, producto, factura);

String cedula = "1723713556";
String nombre = "gabo";
String direccion = "quito sur";
String telefono = "2621561";

        
        ManejadorCliente manejadorCliente = new ManejadorCliente();
        manejadorCliente.crear(new Cliente(cedula, nombre, direccion, telefono));
        

    }

}
