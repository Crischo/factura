/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.persistencia;

import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.conexion.Conexion;
import modelo.entidades.Cliente;

/**
 *
 * @author gabriel
 */
public class ClienteDao implements Crudable<Cliente> {

    @Override
    public Cliente crear(Cliente cliente) {
        try {
            Conexion conexion = new Conexion();
            
            
            Connection miConexion  = conexion.obtener();
            PreparedStatement consulta;

            consulta = miConexion.prepareStatement("INSERT INTO cliente (cedula, nombre, direccion,telefono) VALUES(?, ?, ?,?)");
            consulta.setString(1, cliente.getCedula());
            consulta.setString(2, cliente.getNombre());
            consulta.setString(3, cliente.getDireccion());
            consulta.setString(4, cliente.getTelefono());
            System.out.println(consulta.executeUpdate());
            
            return cliente;
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
       return cliente;
    }

    @Override
    public Cliente editar(Cliente objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminar(Cliente objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cliente> leer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
