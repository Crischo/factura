/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.logica;

import java.util.List;
import modelo.entidades.Cabecera;
import modelo.entidades.Cliente;
import modelo.persistencia.CabeceraDao;

/**
 *
 * @author gabriel
 */
public class ManejadorCabecera implements Gestionable<Cabecera>{

  
    @Override
    public Cabecera crear(Cabecera cabecera) {
        CabeceraDao dao = new CabeceraDao();
        return dao.crear(cabecera);
    }

    @Override
    public Cabecera editar(Cabecera objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminar(Cabecera objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cabecera> leer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
