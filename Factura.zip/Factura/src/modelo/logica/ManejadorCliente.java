/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.logica;

import java.util.List;
import modelo.entidades.Cliente;
import modelo.persistencia.CabeceraDao;
import modelo.persistencia.ClienteDao;



/**
 *
 * @author gabriel
 */
public class ManejadorCliente implements Gestionable<Cliente>{

    @Override
    public Cliente crear(Cliente cliente) {
        ClienteDao dao = new ClienteDao();
        return dao.crear(cliente);
    }

    @Override
    public Cliente editar(Cliente objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminar(Cliente objeto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Cliente> leer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  
}
